#!/bin/bash
#
# #################################################################
#
# Written by        : TheGreatYellow (TgY)
# Version           : v1
# Start date        : 27/04/2017
# Last modified date: 27/04/2017
#
# #################################################################

###################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
###################################################################

echo "Hiding xfce4 panel icons from menus"
old="NoDisplay=false"
new="NoDisplay=true"
location="~/.local/share/applications/"

for file in xfce4*.desktop; do
    sed -i s/$old/$new/g $file
done

###################################################################

echo ""
echo "################################################################"
echo "# Hiding xfce4 panel icons from menus done                     #"
echo "################################################################"
echo ""

