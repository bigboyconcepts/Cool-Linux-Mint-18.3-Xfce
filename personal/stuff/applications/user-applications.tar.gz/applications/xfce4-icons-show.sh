#!/bin/bash
#
# #################################################################
#
# Written by        : TheGreatYellow (TgY)
# Version           : v1
# Start date        : 27/04/2017
# Last modified date: 27/04/2017
#
# #################################################################

###################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
###################################################################

echo "Showing xfce4 panel icons from menus"
old="NoDisplay=true"
new="NoDisplay=false"
location="~/.local/share/applications/"

for file in xfce4*.desktop; do
    sed -i s/$old/$new/g $file
done

###################################################################

echo ""
echo "################################################################"
echo "# Showing xfce4 panel icons from menus done                    #"
echo "################################################################"
echo ""

